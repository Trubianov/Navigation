//
//  MyNavigationController.h
//  FirstTest
//
//  Created by admin on 06.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNavigationController : UINavigationController


@end
