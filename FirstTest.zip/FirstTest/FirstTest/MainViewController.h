//
//  MainViewController.h
//  FirstTest
//
//  Created by admin on 11.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyNavigationController.h"

@interface MainViewController : UIViewController

@property (nonatomic, strong) MyNavigationController *myNavigationController;

@end
