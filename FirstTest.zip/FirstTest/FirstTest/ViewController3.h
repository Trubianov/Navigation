//
//  SinglePhotoViewController.h
//  FirstTest
//
//  Created by admin on 06.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController3 : UIViewController

@end
