//
//  MyNavigationController.m
//  FirstTest
//
//  Created by admin on 06.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import "MyNavigationController.h"
#import "ViewController2.h"

@interface MyNavigationController ()

@end

@implementation MyNavigationController


- (BOOL)shouldAutorotate
{
   return [self.topViewController shouldAutorotate];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return [self.topViewController supportedInterfaceOrientations];
}

@end
