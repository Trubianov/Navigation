//
//  ViewController.m
//  FirstTest
//
//  Created by admin on 02.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import "ViewController2.h"
#import "ViewController3.h"

@interface ViewController2 ()

@end

@implementation ViewController2


- (IBAction)ChangeOrientation:(UIButton *)sender
{
    [self.navigationController pushViewController:[ViewController3 new] animated:YES];
}

- (BOOL)shouldAutorotate
{
    return  YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
