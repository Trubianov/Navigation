//
//  ViewController1.m
//  FirstTest
//
//  Created by admin on 11.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import "ViewController1.h"
#import "ViewController2.h"

@interface ViewController1 ()

@end

@implementation ViewController1

- (IBAction)pushController:(id)sender
{
    [self.navigationController pushViewController:[ViewController2 new] animated:YES];
}

@end
