//
//  MainViewController.m
//  FirstTest
//
//  Created by admin on 11.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import "MainViewController.h"
#import "MyNavigationController.h"

@interface MainViewController ()



@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view addSubview:self.myNavigationController.view];
}

- (BOOL)shouldAutorotate
{
    return [self.myNavigationController.topViewController shouldAutorotate];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return [self.myNavigationController.topViewController supportedInterfaceOrientations];
}


@end
