//
//  SinglePhotoViewController.m
//  FirstTest
//
//  Created by admin on 06.11.13.
//  Copyright (c) 2013 admin. All rights reserved.
//

#import "ViewController3.h"

@interface ViewController3 ()

@end

@implementation ViewController3


- (BOOL)shouldAutorotate
{
    return  YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

@end
